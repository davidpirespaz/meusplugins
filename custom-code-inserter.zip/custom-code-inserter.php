<?php
/**
 * Plugin Name: Custom Code Inserter
 * Description: Insere códigos HTML ou JS personalizados em parágrafos específicos ou antes/depois de <h2> em postagens pertencentes a diferentes categorias.
 * Version: 3.0
 * Author: David Pires Paz
 * Author URI: https://github.com/davidpirespaz
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Adiciona o submenu no menu de configurações
function cci_add_admin_menu() {
    add_options_page(
        'Custom Code Inserter',
        'Custom Code Inserter',
        'manage_options',
        'custom-code-inserter',
        'cci_options_page'
    );
}
add_action( 'admin_menu', 'cci_add_admin_menu' );

// Renderiza a página de opções
function cci_options_page() {
    ?>
    <div class="wrap">
        <h1>Custom Code Inserter</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields( 'cci_options_group' );
            do_settings_sections( 'cci_options_group' );
            ?>
            <table class="form-table">
                <?php for ( $i = 1; $i <= 5; $i++ ) : ?>
                <tr valign="top">
                    <th scope="row">Categoria <?php echo $i; ?></th>
                    <td>
                        <?php
                        wp_dropdown_categories( array(
                            'name' => 'cci_category_' . $i,
                            'selected' => get_option( 'cci_category_' . $i ),
                            'show_option_all' => 'Selecione uma categoria',
                        ) );
                        ?>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Número do Parágrafo <?php echo $i; ?></th>
                    <td>
                        <input type="number" name="cci_paragraph_number_<?php echo $i; ?>" value="<?php echo esc_attr( get_option( 'cci_paragraph_number_' . $i ) ); ?>" min="1" />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Código Personalizado (HTML/JS) <?php echo $i; ?></th>
                    <td>
                        <textarea name="cci_custom_code_<?php echo $i; ?>" rows="10" cols="50"><?php echo esc_textarea( get_option( 'cci_custom_code_' . $i ) ); ?></textarea>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Posição do Código em Relação ao <h2> <?php echo $i; ?></th>
                    <td>
                        <select name="cci_position_<?php echo $i; ?>">
                            <option value="none" <?php selected( get_option( 'cci_position_' . $i ), 'none' ); ?>>Nenhum</option>
                            <option value="before" <?php selected( get_option( 'cci_position_' . $i ), 'before' ); ?>>Antes</option>
                            <option value="after" <?php selected( get_option( 'cci_position_' . $i ), 'after' ); ?>>Depois</option>
                        </select>
                    </td>
                </tr>
                <?php endfor; ?>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Registra configurações
function cci_register_settings() {
    for ( $i = 1; $i <= 5; $i++ ) {
        register_setting( 'cci_options_group', 'cci_category_' . $i );
        register_setting( 'cci_options_group', 'cci_paragraph_number_' . $i );
        register_setting( 'cci_options_group', 'cci_custom_code_' . $i );
        register_setting( 'cci_options_group', 'cci_position_' . $i );
    }
}
add_action( 'admin_init', 'cci_register_settings' );

// Função para inserir código personalizado antes ou depois de <h2>
function cci_insert_code_around_h2( $content, $custom_code, $position ) {
    if ( $position === 'before' ) {
        $content = preg_replace( '/<h2/i', $custom_code . '<h2', $content, 1 );
    } elseif ( $position === 'after' ) {
        $content = preg_replace( '/<\/h2>/i', '</h2>' . $custom_code, $content, 1 );
    }
    return $content;
}

// Filtra o conteúdo da postagem para inserir os códigos personalizados
function cci_insert_custom_code( $content ) {
    if ( is_single() ) {
        for ( $i = 1; $i <= 5; $i++ ) {
            $category = get_option( 'cci_category_' . $i );
            if ( in_category( $category ) ) {
                $paragraph_number = get_option( 'cci_paragraph_number_' . $i );
                $custom_code = '<div>' . get_option( 'cci_custom_code_' . $i ) . '</div>';
                $position = get_option( 'cci_position_' . $i );

                if ( $position !== 'none' ) {
                    $content = cci_insert_code_around_h2( $content, $custom_code, $position );
                } else {
                    $paragraphs = explode( '</p>', $content );

                    if ( count( $paragraphs ) >= $paragraph_number ) {
                        // Insere o código personalizado em um novo <div>
                        $paragraphs[$paragraph_number - 1] .= '</p>' . $custom_code;
                    }

                    $content = implode( '</p>', $paragraphs );
                }
            }
        }
    }

    return $content;
}
add_filter( 'the_content', 'cci_insert_custom_code' );